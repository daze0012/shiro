from setuptools import setup

setup(
    name='shiro',
    version='1.0',
    description='一些工具',
    author='shiro',
    author_email='tangshiro.0@gmail.com',
    py_modules=['__init__', 'utils'],
)
